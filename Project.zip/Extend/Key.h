#ifndef __Key_H
#define __Ket_H

void Key_Init(void);
int KeyKeep(void);
int Key_1(void);
int Key_2(void);

#endif
